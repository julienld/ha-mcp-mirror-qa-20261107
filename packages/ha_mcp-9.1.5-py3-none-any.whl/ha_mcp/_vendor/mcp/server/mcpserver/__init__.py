"""MCPServer - A more ergonomic interface for MCP servers."""

from ha_mcp._vendor.mcp_types import Icon

from ha_mcp._vendor.mcp.server.extension import Extension, MethodBinding, ResourceBinding, ToolBinding
from ha_mcp._vendor.mcp.server.request_state import (
    AESGCMRequestStateCodec,
    InvalidRequestState,
    RequestStateBoundary,
    RequestStateCodec,
    RequestStateSecurity,
    authenticated_principal,
)

from .context import Context
from .prompts.base import AssistantMessage, Message, UserMessage
from .resolve import (
    AcceptedElicitation,
    CancelledElicitation,
    DeclinedElicitation,
    Elicit,
    ElicitationResult,
    ListRoots,
    Resolve,
    Sample,
)
from .resources import DEFAULT_RESOURCE_SECURITY, ResourceSecurity
from .server import MCPServer, require_client_extension
from .utilities.types import Audio, Image

__all__ = [
    "MCPServer",
    "Context",
    "Image",
    "Audio",
    "Message",
    "UserMessage",
    "AssistantMessage",
    "Icon",
    "Resolve",
    "Elicit",
    "Sample",
    "ListRoots",
    "ElicitationResult",
    "AcceptedElicitation",
    "DeclinedElicitation",
    "CancelledElicitation",
    "Extension",
    "ToolBinding",
    "ResourceBinding",
    "MethodBinding",
    "require_client_extension",
    "ResourceSecurity",
    "DEFAULT_RESOURCE_SECURITY",
    "RequestStateSecurity",
    "RequestStateCodec",
    "RequestStateBoundary",
    "AESGCMRequestStateCodec",
    "InvalidRequestState",
    "authenticated_principal",
]
