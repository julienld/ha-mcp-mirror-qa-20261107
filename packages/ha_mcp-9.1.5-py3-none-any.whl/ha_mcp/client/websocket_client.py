"""
WebSocket client for Home Assistant real-time communication.

This module handles WebSocket connections to Home Assistant for:
- Real-time state change monitoring
- Async device operation verification
- Live system updates
"""

import asyncio
import concurrent.futures
import hashlib
import json
import logging
import ssl
import time
from collections.abc import Awaitable, Callable, Coroutine
from typing import Any
from urllib.parse import urlparse

import anyio

# The vendored copy, NEVER the shared site-packages one: inside Home
# Assistant that copy is unowned — ~20 integration libraries drag it in with
# conflicting version demands and any of their installs can replace or tear
# it in place (#2135/#2146). The private copy is immune, and CI tests
# exactly the version production runs.
from .._vendor import websockets
from .._vendor.websockets.exceptions import ConnectionClosed
from ..config import get_global_settings
from .rest_client import (
    HomeAssistantAuthError,
    HomeAssistantCommandError,
    HomeAssistantCommandNotSent,
    HomeAssistantCommandTimeout,
    HomeAssistantConnectionError,
    _is_ssl_error,
)
from .websocket_state import WebSocketConnectionState

logger = logging.getLogger(__name__)

# Matches the Supervisor's own Core-connection receive limit
# (MAX_MESSAGE_SIZE_FROM_CORE in home-assistant/supervisor, see supervisor
# issue #4392). On the add-on path frames above that limit die at the
# Supervisor proxy anyway, so a larger client-side cap adds nothing there.
# Registry list responses scale with entity count and arrive as ONE frame
# (the HA WebSocket API has no pagination); a ~6.4k-entity instance
# overflowed the previous 20MB cap (#1721).
MAX_WS_MESSAGE_BYTES = 64 * 1024 * 1024


# How long a cancellation path waits for its own cleanup. Bounded because
# the caller is already being torn down and must not be held indefinitely;
# awaited rather than abandoned because a cleanup that outlives its call
# acts on whatever the client looks like later, not on what it was cleaning
# up. Matches the theme-guard session close, which solves the same problem.
CLEANUP_TIMEOUT_SECONDS = 2.0

# Structured error codes that mean the subscription is already gone, which
# is the ordinary outcome when releasing one that was abandoned before Home
# Assistant registered it. Everything else is a refusal of the release, and
# leaves the subscription open.
#
# An absent code counts as gone rather than as a refusal. Home Assistant's
# unsubscribe handler answers either success or not_found and nothing else,
# so for THIS command an error without a structured code is still that same
# answer from a build that did not send one. The codes worth distinguishing
# -- unauthorised, malformed, unknown command -- come from the layer above
# the handler and do carry one. Treating a missing code as a refusal would
# put a warning on the routine path, which fires on every cancelled
# subscribe.
_SUBSCRIPTION_GONE_CODES = frozenset({"not_found"})
# How long :meth:`HomeAssistantWebSocketClient.send_command` waits for a reply
# when the caller names no ``_wait_timeout``. Named rather than inlined because
# callers that schedule retries have to budget around it: a caller whose retry
# delay assumes a fast failure will start its next attempt one whole timeout
# later than it planned when the command hangs instead.
DEFAULT_COMMAND_WAIT_TIMEOUT = 30.0

# Field names whose value must never reach the log, matched case-insensitively
# wherever they appear in a received frame. The approval-response event carries
# the user's approval PIN in ``event.data.pin`` (issue #2502), and the debug
# line below prints whole decoded frames -- so without this, turning on debug
# logging would write that PIN into Home Assistant's log in clear text.
_REDACTED_LOG_FIELDS = frozenset({"pin"})
_REDACTED_PLACEHOLDER = "<redacted>"


def _redacted_for_log(value: Any) -> Any:
    """A copy of ``value`` with ``_REDACTED_LOG_FIELDS`` masked.

    Only for logging: the caller keeps handling the original, so redaction
    cannot change what the client does with a frame -- verification still
    sees the real PIN. Containers are rebuilt rather than mutated for the
    same reason. Anything that is not a dict or a list is returned as it
    is, which is why this stays cheap enough to run per frame; the caller
    runs it only when DEBUG is actually enabled.
    """
    if isinstance(value, dict):
        return {
            key: (
                _REDACTED_PLACEHOLDER
                if isinstance(key, str) and key.lower() in _REDACTED_LOG_FIELDS
                else _redacted_for_log(item)
            )
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_redacted_for_log(item) for item in value]
    return value


def _log_received_frame(data: Any) -> None:
    """Debug-log one received frame, with secret fields masked.

    Its own function so the redaction cannot cost the message loop a
    branch it does not need: the guard keeps the copy from being built at
    all when DEBUG is off, which is every production deployment.
    """
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("WebSocket received: %s", _redacted_for_log(data))


def _extract_ws_error(error: Any) -> tuple[str, str | None]:
    """Split an HA WebSocket ``error`` payload into ``(message, code)``.

    HA replies to a failed command with ``{"error": {"code": ..., "message":
    ...}}``. Dict payloads yield both fields; a bare string (or other shape)
    yields ``str(error)`` as the message and ``None`` for the code. The code is
    threaded onto ``HomeAssistantCommandError`` so callers route on the stable
    ``code`` (e.g. ``unknown_command``) instead of the message text.
    """
    if isinstance(error, dict):
        return error.get("message", str(error)), error.get("code")
    return str(error), None


class HomeAssistantWebSocketClient:
    """WebSocket client for Home Assistant real-time communication."""

    def __init__(self, url: str, token: str, verify_ssl: bool | None = None):
        """Initialize WebSocket client.

        Args:
            url: Home Assistant URL (e.g., 'https://homeassistant.local:8123')
            token: Home Assistant long-lived access token
            verify_ssl: Whether to verify the HA server's TLS certificate
                for ``wss://`` connections. Defaults to
                ``settings.verify_ssl``. Pass False to allow self-signed
                certs or hostname mismatches.
        """
        self.base_url = url.rstrip("/")
        self.token = token
        if verify_ssl is None:
            try:
                verify_ssl = get_global_settings().verify_ssl
            except Exception as e:  # noqa: BLE001
                # A bad env var elsewhere should not silently flip TLS off:
                # log which key tripped and fall back to the secure default.
                logger.warning(
                    "Could not load settings while resolving verify_ssl "
                    "(%s); falling back to verify_ssl=True.",
                    e,
                )
                verify_ssl = True
        self.verify_ssl = verify_ssl
        self._warned_verify_disabled = False
        self.websocket: websockets.ClientConnection | None = None
        self.background_task: asyncio.Task | None = None
        self._send_lock: asyncio.Lock | None = None
        self._lock_loop: asyncio.AbstractEventLoop | None = None
        self._state = WebSocketConnectionState()
        # Releases of subscriptions acknowledged after their caller gave up,
        # held here so the tasks are not garbage-collected mid-flight.
        self._late_releases: set[asyncio.Task[None]] = set()
        # Reason the most recent connect() attempt failed (exception text),
        # or None. Surfaced by callers so the agent sees *why* a WebSocket
        # connection failed instead of an opaque "Failed to connect" string.
        self._last_connect_error: str | None = None
        # The exception object itself, so the connection manager can
        # re-raise an auth failure AS an auth failure instead of collapsing
        # every connect miss into HomeAssistantConnectionError (issue #2159
        # review: an expired token must classify as AUTH_*, and the reason
        # otherwise survives only inside the message string).
        self._last_connect_exception: Exception | None = None

        # Parse URL to get WebSocket endpoint
        parsed = urlparse(self.base_url)
        scheme = "wss" if parsed.scheme == "https" else "ws"

        # Handle Supervisor proxy case: http://supervisor/core -> ws://supervisor/core/websocket
        # For regular HA URLs: http://ha.local:8123 -> ws://ha.local:8123/api/websocket
        if parsed.path and parsed.path != "/":
            # Supervisor proxy or URL with path - use path + /websocket
            base_path = parsed.path.rstrip("/")
            self.ws_url = f"{scheme}://{parsed.netloc}{base_path}/websocket"
        else:
            # Standard Home Assistant URL - use /api/websocket
            self.ws_url = f"{scheme}://{parsed.netloc}/api/websocket"

    async def connect(self) -> bool:
        """Connect to Home Assistant WebSocket API.

        Returns:
            True if connection and authentication successful
        """
        try:
            logger.info(f"Connecting to Home Assistant WebSocket: {self.ws_url}")
            self._state.reset_connection()
            self._last_connect_error = None
            self._last_connect_exception = None

            # Only configure an SSLContext for wss://; ws:// (Supervisor
            # proxy) doesn't use TLS and gets ssl=None.
            ssl_ctx: ssl.SSLContext | None = None
            if self.ws_url.startswith("wss://"):
                ssl_ctx = ssl.create_default_context()
                if not self.verify_ssl:
                    if not self._warned_verify_disabled:
                        # Once per client — pool reconnects/HA restarts
                        # otherwise flood logs with the same warning.
                        logger.warning(
                            "TLS verification disabled for Home Assistant "
                            "WebSocket (HA_VERIFY_SSL=false). Connecting to "
                            "%s with hostname/cert checks off.",
                            self.ws_url,
                        )
                        self._warned_verify_disabled = True
                    ssl_ctx.check_hostname = False
                    ssl_ctx.verify_mode = ssl.CERT_NONE

            # Connect to WebSocket
            # Include Authorization header for Supervisor proxy compatibility
            # (required when connecting via http://supervisor/core/websocket)
            self.websocket = await websockets.connect(
                self.ws_url,
                ping_interval=30,
                ping_timeout=10,
                additional_headers={"Authorization": f"Bearer {self.token}"},
                ssl=ssl_ctx,
                max_size=MAX_WS_MESSAGE_BYTES,
            )
            self._state.mark_connected()

            # Start message handling task
            self.background_task = asyncio.create_task(self._message_handler())

            # Wait for auth_required message
            auth_msg = await self._wait_for_auth_message(
                message_type="auth_required", timeout=5
            )
            if not auth_msg:
                raise HomeAssistantConnectionError(
                    "Did not receive auth_required message"
                )

            # Send authentication
            await self._send_auth()

            # Wait for auth response
            auth_response = await self._wait_for_auth_message("auth_ok", timeout=5)
            if not auth_response:
                raise HomeAssistantConnectionError("Authentication timeout")

            self._state.mark_authenticated()
            logger.info("WebSocket connected and authenticated successfully")
            return True

        except Exception as e:  # noqa: BLE001
            self._last_connect_error = f"{type(e).__name__}: {e}"
            self._last_connect_exception = e
            if _is_ssl_error(e) and self.verify_ssl:
                logger.error(
                    "WebSocket TLS verification failed for %s: %s. "
                    "If this is a self-signed certificate or hostname "
                    "mismatch, set HA_VERIFY_SSL=false to skip verification.",
                    self.ws_url,
                    e,
                )
            else:
                logger.error(f"WebSocket connection failed: {e}")
            await self.disconnect()
            return False

        except BaseException:
            # Everything that is not an ``Exception`` -- a cancellation above
            # all -- used to skip the clause above entirely, leaving the
            # reader task started earlier and the open socket behind with
            # nothing tracking them: the pool only takes the client once
            # connect has returned True, so nothing else would ever close
            # them. Ordered after the ``Exception`` handler so the ordinary
            # failure path is unchanged, and it re-raises unconditionally --
            # only the tidying happens here, and it is bounded because
            # awaiting it plainly would be cancelled in turn.
            await self._run_cleanup(self.disconnect(), "cancelled connect")
            raise

    async def disconnect(self) -> None:
        """Disconnect from WebSocket."""
        if self.background_task:
            self.background_task.cancel()
            try:
                await self.background_task
            except asyncio.CancelledError:
                # Expected: we just cancelled the task above; swallow the
                # propagated CancelledError so disconnect can finish cleanly.
                pass
            finally:
                self.background_task = None

        if self.websocket:
            await self.websocket.close()
            self.websocket = None

        self._state.mark_disconnected()
        logger.info("WebSocket disconnected")

    async def _send_auth(self) -> None:
        """Send authentication message."""
        if not self.websocket:
            raise HomeAssistantConnectionError("WebSocket not connected")
        auth_message = {"type": "auth", "access_token": self.token}
        await self.websocket.send(json.dumps(auth_message))

    async def _wait_for_auth_message(
        self, message_type: str, timeout: float = 5.0
    ) -> dict[str, Any] | None:
        """Wait for an authentication message type with timeout."""
        start_time = time.time()

        while time.time() - start_time < timeout:
            if isinstance(self._last_connect_exception, HomeAssistantAuthError):
                raise self._last_connect_exception
            message = self._state.consume_auth_message(message_type)
            if message:
                return message
            await asyncio.sleep(0.01)  # Small delay to prevent busy waiting

        return None

    async def _message_handler(self) -> None:
        """Background task to handle incoming WebSocket messages."""
        if not self.websocket:
            raise HomeAssistantConnectionError("WebSocket not connected")
        # None means a clean exit (the async-for loop simply ended); the
        # except blocks below fill this in so pending futures — and the
        # log — carry *why* the connection went away instead of a bare
        # "WebSocket connection closed" that gave no lead on #1721.
        close_reason: str | None = None
        try:
            async for message in self.websocket:
                try:
                    data = json.loads(message)
                    _log_received_frame(data)
                    await self._process_message(data)
                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON received: {e}")
                except Exception as e:  # noqa: BLE001
                    logger.error(f"Error processing message: {e}")
        except ConnectionClosed as e:
            # Prefer the frame we received (the peer closed on us); fall
            # back to the frame we sent (we failed the connection
            # ourselves, e.g. an over-max_size frame produces a sent
            # Close(1009, ...) with no frame received at all).
            close = e.rcvd if e.rcvd is not None else e.sent
            if close is not None:
                verb = "received" if e.rcvd is not None else "sent"
                close_reason = f"{verb} close code {close.code}"
                if close.reason:
                    close_reason = f"{close_reason} ({close.reason})"
            else:
                close_reason = "connection dropped without a close frame"

            log_message = f"WebSocket connection closed ({close_reason})"
            if close is None or close.code not in (1000, 1001):
                logger.warning(log_message)
            else:
                logger.info(log_message)
        except Exception as e:  # noqa: BLE001
            close_reason = str(e)
            logger.error(f"WebSocket message handler error: {e}")
        finally:
            self._state.mark_disconnected(close_reason)

    async def _process_message(self, data: dict[str, Any]) -> None:
        """Process incoming WebSocket message."""
        message_type = data.get("type")
        message_id = data.get("id")

        # Handle authentication messages (store for auth sequence)
        if message_type in ["auth_required", "auth_ok", "auth_invalid"]:
            if message_type == "auth_invalid":
                self._last_connect_exception = HomeAssistantAuthError(
                    "Authentication failed: Invalid token"
                )
            self._state.store_auth_message(message_type, data)
            return

        # Handle command responses. An event frame is never the reply to a
        # command, even when it shares the command's id and arrives first:
        # render_template reports template errors as events before its result
        # frame (#2522).
        if message_id is not None and message_type != "event":
            future = self._state.resolve_pending_request(message_id)
            if future:
                if not future.cancelled():
                    future.set_result(data)
                return
            if self._state.take_abandoned_subscription(message_id):
                if message_type == "result" and data.get("success"):
                    task = asyncio.ensure_future(
                        self._release_abandoned_subscription(message_id)
                    )
                    self._late_releases.add(task)
                    task.add_done_callback(self._late_release_done)
                return

        # Handle events
        if message_type == "event":
            await self._handle_event_message(data, message_id)

    async def _handle_event_message(
        self, data: dict[str, Any], message_id: int | None
    ) -> None:
        """Handle an incoming event message."""
        if message_id is not None:
            # Continuous subscriptions take priority: a single ``hacs/subscribe``
            # can deliver many events sharing one id and the one-shot
            # ``_event_responses`` future would only catch the first.
            # Events delivered to a subscription queue do NOT also
            # fan out to ``add_event_handler`` listeners below — the
            # ``return`` here is intentional; subscribe-via-queue and
            # the legacy event-type registry are mutually exclusive
            # routes for a given message id.
            queue = self._state.get_subscription_queue(message_id)
            if queue is not None:
                try:
                    queue.put_nowait(data)
                except asyncio.QueueShutDown:
                    # Caller unsubscribed between dispatch and delivery —
                    # drop the event quietly rather than logging an
                    # error for an expected lifecycle race.
                    pass
                return

            render_future = self._state.resolve_event_response(message_id)
            if render_future:
                if not render_future.cancelled():
                    render_future.set_result(data)
                return

        event_type = data.get("event", {}).get("event_type")
        if event_type:
            for handler in self._state.get_event_handlers(event_type):
                try:
                    await handler(data["event"])
                except Exception as e:
                    # ``exc_info=True`` so handler bugs (AttributeError /
                    # KeyError / TypeError from schema-drift on the
                    # incoming event payload) leave a traceback rather
                    # than a one-line obscured error. Without this the
                    # dispatch loop keeps a single buggy handler from
                    # killing the WS, but the bug itself becomes
                    # invisible — handlers wired to ``asyncio.Event``
                    # nudges (see ``ws_waiters._ws_wait_for_condition``)
                    # silently stop nudging and the calling waiter times
                    # out reporting "not found." #1395 silent-failure
                    # audit.
                    logger.error("Error in event handler: %s", e, exc_info=True)

    def _ensure_send_lock(self) -> None:
        """Ensure the send lock belongs to the current event loop."""
        try:
            current_loop = asyncio.get_running_loop()
        except RuntimeError:
            current_loop = None

        if (
            self._send_lock is not None
            and self._lock_loop is not None
            and self._lock_loop != current_loop
        ):
            logger.debug("Event loop changed, resetting WebSocket send lock")
            self._send_lock = None

        if self._send_lock is None:
            self._send_lock = asyncio.Lock()
            self._lock_loop = current_loop

    async def send_json_message(self, message: dict[str, Any]) -> None:
        """Send a raw JSON message over the WebSocket connection."""
        self._ensure_send_lock()
        if not self._send_lock:
            raise Exception("Send lock not initialized")

        async with self._send_lock:
            if not self.websocket:
                raise HomeAssistantConnectionError("WebSocket not connected")
            logger.debug(f"WebSocket sending: {message}")
            await self.websocket.send(json.dumps(message))

    def get_next_message_id(self) -> int:
        """Expose the next WebSocket message ID for external callers."""
        return self._state.next_message_id()

    def register_pending_response(
        self, message_id: int
    ) -> asyncio.Future[dict[str, Any]]:
        """Register a future that will resolve when the response arrives."""
        return self._state.register_pending_request(message_id)

    def cancel_pending_response(self, message_id: int) -> None:
        """Cancel and drop a pending response future."""
        self._state.cancel_pending_request(message_id)

    def register_event_response(
        self, message_id: int
    ) -> asyncio.Future[dict[str, Any]]:
        """Register a future for a follow-up event."""
        return self._state.register_event_response(message_id)

    def cancel_event_response(self, message_id: int) -> None:
        """Cancel and drop a stored event future."""
        self._state.cancel_event_response(message_id)

    async def send_command(self, command_type: str, **kwargs: Any) -> dict[str, Any]:
        """Send command and wait for response.

        Args:
            command_type: Type of command to send
            _wait_timeout: Seconds to wait for the response (consumed from
                ``kwargs``, not forwarded to Home Assistant). Defaults to
                ``DEFAULT_COMMAND_WAIT_TIMEOUT``, which suits fast commands;
                long-running ones (e.g. a ``supervisor/api`` add-on install)
                must raise this so the client doesn't give up before Home
                Assistant replies.
            **kwargs: Command parameters (merged into the outgoing message)

        Returns:
            Response from Home Assistant
        """
        if not self._state.is_ready:
            # PRE-SEND and send_command's only provably-never-sent site: nothing is
            # transmitted here. Raise the never-sent subtype so an at-most-once write
            # consumer can fall back to legacy safely (a subclass of
            # HomeAssistantConnectionError, so every existing broad handler is
            # unaffected). A later send() failure is NOT never-sent (see below).
            raise HomeAssistantCommandNotSent("WebSocket not authenticated")

        # Pull the wait timeout out of kwargs rather than making it a positional
        # parameter: callers unpack a ``dict[str, object]`` via
        # ``send_command(cmd, **message)``, and a typed positional param would
        # break that call shape under mypy. The leading underscore keeps it out
        # of the HA message namespace — HA WebSocket fields never start with
        # one — so it can never shadow a real command field when popped.
        wait_timeout: float = kwargs.pop("_wait_timeout", DEFAULT_COMMAND_WAIT_TIMEOUT)

        message_id = self.get_next_message_id()
        message = {"id": message_id, "type": command_type, **kwargs}

        # Create future for response
        future = self.register_pending_response(message_id)

        try:
            await self.send_json_message(message)
        except Exception:
            # AMBIGUOUS, not never-sent: websocket.send() raising (e.g. a
            # ConnectionClosed detected mid-write) does NOT prove the frame was not
            # transmitted — bytes may already be on the socket when the close surfaces.
            # Re-raise the ORIGINAL exception unchanged so an at-most-once write
            # consumer treats it like a post-send drop (ambiguous -> partial, never
            # re-fired), NOT as never-sent; only the readiness guard above is provably
            # never-sent. Still cancel the pending future so it cannot leak.
            self.cancel_pending_response(message_id)
            raise
        except BaseException:
            # Cancellation mid-send: same leak potential as the response-wait
            # clause below — drop the registered future before propagating.
            self.cancel_pending_response(message_id)
            raise

        # Wait for response outside the lock.
        try:
            response = await asyncio.wait_for(future, timeout=wait_timeout)
            logger.debug(f"WebSocket response for id {message_id}: {response}")

            # Process standard Home Assistant WebSocket response
            if response.get("type") == "result":
                if response.get("success") is False:
                    error_msg, error_code = _extract_ws_error(response.get("error", {}))
                    raise HomeAssistantCommandError(
                        f"Command failed: {error_msg}", error_code
                    )

                # Return success response according to HA WebSocket format
                return {
                    "success": response.get("success", True),
                    "result": response.get("result"),
                }
            elif response.get("type") == "pong":
                # Pong responses are normal keep-alive messages, handle silently
                return {"success": True, "type": "pong"}
            else:
                # Log unexpected response format
                logger.warning(
                    f"Unexpected WebSocket response type: {response.get('type')}"
                )
                return {"success": True, **response}

        except TimeoutError as e:
            self.cancel_pending_response(message_id)
            raise HomeAssistantCommandTimeout("Command timeout") from e
        except Exception:
            self.cancel_pending_response(message_id)
            raise
        except BaseException:
            # Cancellation (or another BaseException) while awaiting the
            # response: without this clause the registered future stays in
            # _pending_requests until a response with this id arrives — which a
            # hung handler never sends — leaking one entry per cancelled call
            # (e.g. the ha_search dashboards leg cancelled on a component-leg
            # failure, #2291).
            self.cancel_pending_response(message_id)
            raise

    async def send_command_with_event(
        self,
        command_type: str,
        wait_timeout: float = 10.0,
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Send a command that returns a result followed by an event response.

        Some HA WebSocket commands (e.g. system_health/info) reply with an
        immediate result message and then deliver the actual data in a
        subsequent event message sharing the same message ID.

        Args:
            command_type: Type of command to send.
            wait_timeout: Seconds to wait for each response phase.
            **kwargs: Additional fields merged into the outgoing message.

        Returns:
            A (result_response, event_response) tuple.
        """
        if not self._state.is_ready:
            raise HomeAssistantConnectionError("WebSocket not authenticated")

        message_id = self.get_next_message_id()
        message = {"id": message_id, "type": command_type, **kwargs}

        result_future = self.register_pending_response(message_id)
        event_future = self.register_event_response(message_id)

        try:
            await self.send_json_message(message)
        except Exception:
            self.cancel_pending_response(message_id)
            self.cancel_event_response(message_id)
            raise
        except BaseException:
            # Cancellation mid-send: skips the clause above and would leave BOTH
            # registrations behind — drop them before propagating.
            self.cancel_pending_response(message_id)
            self.cancel_event_response(message_id)
            raise

        try:
            result_response = await asyncio.wait_for(
                result_future, timeout=wait_timeout
            )
        except BaseException:
            self.cancel_pending_response(message_id)
            self.cancel_event_response(message_id)
            # A connection drop fails BOTH futures via reset_connection;
            # only result_future gets awaited on this path, so retrieve
            # event_future's exception too or asyncio logs an ERROR-level
            # "Future exception was never retrieved" when it is GC'd.
            if event_future.done() and not event_future.cancelled():
                event_future.exception()
            raise

        if not result_response.get("success"):
            self.cancel_event_response(message_id)
            error_msg, error_code = _extract_ws_error(result_response.get("error", {}))
            raise HomeAssistantCommandError(f"Command failed: {error_msg}", error_code)

        try:
            event_response = await asyncio.wait_for(event_future, timeout=wait_timeout)
        except BaseException:
            # A cancelled caller leaves the event registration in
            # _event_responses until an event with this id arrives, which
            # nothing sends once the caller is gone. The cleanup is
            # exception-type-independent and the original exception re-raises
            # unchanged.
            self.cancel_event_response(message_id)
            raise

        return result_response, event_response

    async def subscribe_events(self, event_type: str | None = None) -> int:
        """Subscribe to Home Assistant events.

        HA's WebSocket API identifies a subscription by the ``id`` of the
        original ``subscribe_events`` command — not by a field inside the
        ``result`` payload. ``handle_subscribe_events`` in HA Core
        (``websocket_api/commands.py``) ends with
        ``connection.send_result(msg["id"])``, and ``send_result(msg_id)``
        emits ``{"id": N, "type": "result", "success": true, "result": null}``.
        Subsequent event deliveries arrive as
        ``{"id": N, "type": "event", "event": {...}}`` with the same ``id``.

        The previous implementation called ``send_command`` (which discards
        the message_id it generated) and then looked for
        ``response["result"]["subscription"]``, a field HA does not send.
        That branch never matched, so this function always raised
        ``"Failed to get subscription ID"`` — even though the underlying
        subscription on HA's side WAS established. The ``WebSocketListenerService``
        treated the raised exception as a startup failure and left
        ``_listener_started = False``, so every device-control call
        repeatedly retried (and re-failed) and ``OperationManager.process_state_change``
        was never invoked, leaving every async operation in PENDING until
        ``OperationManager.get_operation`` flipped it to TIMEOUT after
        the 10s ``timeout_ms`` budget. Surfaced during PR #1375 HAOS log
        audit (3x "Failed to get subscription ID" per bulk-control test).

        Args:
            event_type: Specific event type to subscribe to (None for all)

        Returns:
            Subscription ID (the message_id used when subscribing)
        """
        if not self._state.is_ready:
            raise HomeAssistantConnectionError("WebSocket not authenticated")

        message_id = self.get_next_message_id()
        message: dict[str, Any] = {"id": message_id, "type": "subscribe_events"}
        if event_type:
            message["event_type"] = event_type

        future = self.register_pending_response(message_id)
        try:
            await self.send_json_message(message)
        except Exception:
            self.cancel_pending_response(message_id)
            raise
        except BaseException:
            # Cancellation mid-send: skips the clause above and would leave the
            # pending future registered — drop it before propagating.
            #
            # And a cancelled send is not proof that Home Assistant received
            # nothing. The vendored implementation writes the frame before it
            # awaits flow-control drainage, so a cancellation landing in that
            # wait can leave the subscription registered on a socket this
            # process keeps using -- the same orphan the acknowledgment path
            # below releases, reached one await earlier. The id is allocated
            # before the send, so it is still known here; an unsubscribe for
            # something that was never registered answers not_found, which
            # the release treats as its ordinary outcome.
            self.cancel_pending_response(message_id)
            self._state.mark_abandoned_subscription(message_id)
            await self._run_cleanup(
                self._release_abandoned_subscription(message_id),
                f"abandoned subscribe_events({message_id})",
            )
            raise

        try:
            response = await asyncio.wait_for(future, timeout=30.0)
        except BaseException:
            # A cancelled caller leaks the pending future, which nothing ever
            # resolves once the caller is gone. The cleanup is
            # exception-type-independent and the original exception re-raises
            # unchanged.
            #
            # The command is already on the wire by this point, so Home
            # Assistant may well have registered the subscription: releasing
            # it is this operation's job, not the caller's, because the id it
            # needs is the one the caller never receives.
            self.cancel_pending_response(message_id)
            self._state.mark_abandoned_subscription(message_id)
            await self._run_cleanup(
                self._release_abandoned_subscription(message_id),
                f"abandoned subscribe_events({message_id})",
            )
            raise

        if response.get("type") == "result" and response.get("success"):
            return message_id

        error_msg, error_code = _extract_ws_error(response.get("error", {}))
        raise HomeAssistantCommandError(
            f"subscribe_events failed: {error_msg}", error_code
        )

    async def unsubscribe_events(self, subscription_id: int) -> None:
        """Release a subscription previously returned by ``subscribe_events``.

        Used by short-lived waiters (``ws_waiters.wait_for_*``) that need
        to drop the subscription as soon as their event arrives so the
        shared socket doesn't accumulate stale ``state_changed`` listeners.

        Exception policy (narrow, distinct log levels — Gemini #1382):

        - Transport-level loss (``OSError``, ``ConnectionClosed``,
          ``HomeAssistantConnectionError``): the socket closed during the send
          or before the answer, and the subscription went with it. Logged at
          ``debug`` so HA-mid-restart cleanup doesn't spam warnings.
        - HA-side rejection (``HomeAssistantCommandError``, e.g. "Subscription
          not found" after a server-side reset): logged at ``warning`` so a
          real subscription leak is discoverable.
        - Everything else, a timeout or a programming bug (TypeError),
          propagates to the caller's ``finally`` instead of a broad ``except``.
        """
        if not self._state.is_ready:
            logger.debug(
                "unsubscribe_events(%s) skipped: WebSocket not ready",
                subscription_id,
            )
            return
        try:
            await self.send_command("unsubscribe_events", subscription=subscription_id)
        except (OSError, ConnectionClosed, HomeAssistantConnectionError) as e:
            logger.debug(
                "unsubscribe_events(%s): transport lost during cleanup: %s",
                subscription_id,
                e,
            )
        except HomeAssistantCommandError as e:
            logger.warning(
                "unsubscribe_events(%s) rejected by HA: %s",
                subscription_id,
                e,
            )

    async def _run_cleanup(self, coro: Coroutine[Any, Any, None], what: str) -> bool:
        """Run ``coro`` to completion or to a deadline, from a cancelled path.

        Returns whether it finished; False means the deadline stopped it.

        Cleanup scheduled while a cancellation is propagating cannot simply
        be awaited: the await is cancelled in turn, and under a cancel scope
        again at every suspension, so the tidying never happens. It also
        must not merely be detached. A detached task reads the client's
        state when it eventually runs, not when it was scheduled, so a
        second ``connect()`` on the same object races it -- measured, the
        stale task closed the NEW socket and left the old one open, the
        exact failure this cleanup exists to prevent.

        So the work is owned by a task, which makes it survive the
        cancellation, and awaited through a shield with a deadline, which
        makes it finish before control returns to anyone. The same shape as
        the theme-guard session cleanup, for the same reason.

        The shield holds against an anyio cancel scope, which is the shape
        this is reached under. A plain ``asyncio.Task.cancel()`` -- what
        ``asyncio.timeout`` issues -- goes through it: measured, the wait
        below then ends at the caller's deadline with the cleanup untouched.
        """
        task = asyncio.ensure_future(coro)
        # Shielded with anyio's scope rather than asyncio's, and around the
        # WAIT as much as around the drain: a cancel scope re-delivers its
        # cancellation to the HOST TASK on every tick while that task is
        # still inside it, and ``asyncio.shield`` only governs propagation
        # from one awaited future -- it does not stop a second ``cancel()``
        # landing on the task at its next await. Such a scope is how this
        # method is reached in the first place: the approval listener opens
        # its subscription inside a ``move_on_after`` setup budget, and a
        # cancelled ``subscribe_events`` is what calls this. Shielding only
        # the drain leaves the wait below cancelled on its first tick, and
        # the ``finally`` then stops the work before it ever had its own
        # budget -- collecting a task is not the same as letting it finish,
        # and cleanup that has to suspend (an unsubscribe waiting for the
        # shared send lock) never reaches its release.
        #
        # What this does NOT do is re-deliver the cancellation it shielded:
        # measured, an enclosing ``move_on_after`` ends with
        # ``cancelled_caught`` False when this returns normally. Each call
        # site raises on its way out, and that raise is what delivers the
        # caller's cancellation -- after the cleanup rather than instead of
        # it. A caller added on a non-raising path would swallow its own
        # deadline here.
        with anyio.CancelScope(shield=True):
            try:
                await asyncio.wait_for(
                    asyncio.shield(task), timeout=CLEANUP_TIMEOUT_SECONDS
                )
            except (Exception, TimeoutError) as e:  # noqa: BLE001
                logger.debug("%s: cleanup did not finish cleanly: %s", what, e)
            except asyncio.CancelledError:
                logger.debug("%s: cleanup cancelled before it finished", what)
                raise
            finally:
                # The inner ``asyncio.shield`` is what lets the deadline
                # expire without killing the work -- and it is equally what
                # would let the work outlive this call, which is the failure
                # being fixed. A task still running here reads the client's
                # state whenever it gets there, so it must not get there:
                # stop it, then collect the outcome so a late failure does
                # not surface as an orphaned "exception was never
                # retrieved".
                finished = task.done()
                if not finished:
                    task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        return finished

    async def _release_abandoned_subscription(self, message_id: int) -> None:
        """Ask Home Assistant to drop a subscription we can no longer name.

        ``subscribe_events`` allocates the message id before sending, so a
        cancelled call still knows the id Home Assistant would have used --
        the id is only lost to the *caller*, which never gets its return
        value. Without this the subscription stays open on a socket this
        process keeps using, the next attempt opens a second one, and every
        event is then delivered once per orphan.

        "Subscription not found" is the ordinary outcome here rather than a
        surprise: the command may never have reached Home Assistant, which
        is exactly the case that needs no cleanup. It is logged at debug for
        that reason, where ``unsubscribe_events`` logs a warning -- there,
        a rejection means a subscription that was known to exist.
        """
        if not self._state.is_ready:
            logger.debug(
                "abandoned subscribe_events(%s): socket not ready, nothing to release",
                message_id,
            )
            return
        try:
            await self.send_command("unsubscribe_events", subscription=message_id)
        except OSError as e:
            logger.debug(
                "abandoned subscribe_events(%s): transport lost before cleanup: %s",
                message_id,
                e,
            )
        except HomeAssistantCommandError as e:
            if e.code is None or e.code in _SUBSCRIPTION_GONE_CODES:
                logger.debug(
                    "abandoned subscribe_events(%s): Home Assistant has no such "
                    "subscription, so the command did not reach it: %s",
                    message_id,
                    e,
                )
            else:
                # Anything else is a rejection of the unsubscribe itself --
                # not authorised, malformed, a command this build does not
                # know. The subscription is then still open on a socket this
                # process keeps using, which is the leak this method exists
                # to prevent, so it must not disappear at debug level with
                # the routine case.
                logger.warning(
                    "abandoned subscribe_events(%s): Home Assistant refused "
                    "the release (code %s); the subscription may still be "
                    "open: %s",
                    message_id,
                    e.code,
                    e,
                )

    async def subscribe_command(
        self,
        command_type: str,
        *,
        wait_timeout: float = 30.0,
        **kwargs: Any,
    ) -> tuple[int, asyncio.Queue[dict[str, Any]]]:
        """Send a subscribe-style command and return (subscription_id, queue).

        For commands that establish a long-lived stream sharing the
        command's ``id`` for every event (HA's ``subscribe_events``,
        HACS' ``hacs/subscribe`` with a ``signal`` field, etc.).
        ``subscribe_events`` has its own dedicated entrypoint above
        because it has additional callers wired to the legacy
        event-type handler registry; use this method for everything
        else.

        ``wait_timeout`` is named apart from ``**kwargs`` because those become
        fields of the command, and some commands (``render_template``) carry a
        ``timeout`` field of their own.

        Returns:
            (subscription_id, queue) — ``await queue.get()`` yields each
            incoming ``{"id": N, "type": "event", "event": ...}`` payload.
            Cancel the subscription via :meth:`unsubscribe_command`, or
            :meth:`release_subscription` from a ``finally``.
        """
        if not self._state.is_ready:
            raise HomeAssistantConnectionError("WebSocket not authenticated")

        message_id = self.get_next_message_id()
        message: dict[str, Any] = {"id": message_id, "type": command_type, **kwargs}

        # Register the queue BEFORE sending so we never miss an event
        # that arrives between the result and the first ``get()``.
        queue = self._state.register_subscription_queue(message_id)
        result_future = self.register_pending_response(message_id)

        try:
            await self.send_json_message(message)
        except Exception:
            self._state.unregister_subscription_queue(message_id)
            self.cancel_pending_response(message_id)
            raise
        except BaseException:
            # Cancellation mid-send: skips the clause above and would leave BOTH
            # the queue and the pending future registered — the queue never
            # drains and buffers every later event for this id forever. The
            # frame may already be on the wire, so release it on Home
            # Assistant's side too, as subscribe_events does.
            self._state.unregister_subscription_queue(message_id)
            self.cancel_pending_response(message_id)
            self._state.mark_abandoned_subscription(message_id)
            await self._run_cleanup(
                self._release_abandoned_subscription(message_id),
                f"abandoned {command_type}({message_id})",
            )
            raise

        try:
            response = await asyncio.wait_for(result_future, timeout=wait_timeout)
        except BaseException:
            # A cancelled caller leaks the pending future AND the subscription
            # queue, which keeps accumulating events with no reader. The
            # command is on the wire, so Home Assistant may have registered
            # the subscription: the caller never receives its id, so releasing
            # it is this method's job. The original exception re-raises
            # unchanged.
            self._state.unregister_subscription_queue(message_id)
            self.cancel_pending_response(message_id)
            self._state.mark_abandoned_subscription(message_id)
            await self._run_cleanup(
                self._release_abandoned_subscription(message_id),
                f"abandoned {command_type}({message_id})",
            )
            raise

        if response.get("type") == "result" and response.get("success"):
            return message_id, queue

        self._state.unregister_subscription_queue(message_id)
        error_msg, error_code = _extract_ws_error(response.get("error", {}))
        raise HomeAssistantCommandError(
            f"subscribe_command({command_type!r}) failed: {error_msg}", error_code
        )

    async def release_subscription(self, subscription_id: int) -> None:
        """Release a :meth:`subscribe_command` subscription from a ``finally``.

        Unlike :meth:`unsubscribe_command` this never raises and survives the
        caller's cancellation: a failed or timed-out release must not replace
        the result the caller already has, and a cancelled caller must still
        release, or Home Assistant keeps the subscription for the life of the
        socket.
        """
        self._state.unregister_subscription_queue(subscription_id)
        socket = self.websocket
        if await self._run_cleanup(
            self._release_abandoned_subscription(subscription_id),
            f"subscription {subscription_id}",
        ):
            return
        # The deadline stopped the release before ``unsubscribe_events`` went
        # out (the send lock was held throughout), and the subscription's ack
        # has already been consumed, so nothing else will release it.
        task = asyncio.ensure_future(self._finish_release(subscription_id, socket))
        self._late_releases.add(task)
        task.add_done_callback(self._late_release_done)

    def _late_release_done(self, task: asyncio.Task[None]) -> None:
        """Collect cleanup outcomes while keeping unexpected failures visible."""
        self._late_releases.discard(task)
        if task.cancelled():
            return
        error = task.exception()
        if isinstance(error, HomeAssistantCommandTimeout) and self._state.is_ready:
            logger.warning(
                "Background subscription release timed out; could not confirm "
                "subscription cleanup in Home Assistant"
            )
        elif isinstance(
            error,
            (
                HomeAssistantConnectionError,
                HomeAssistantCommandTimeout,
                ConnectionClosed,
            ),
        ):
            logger.debug("Background subscription release failed: %s", error)
        elif error is not None:
            logger.error(
                "Unexpected background subscription release failure",
                exc_info=(type(error), error, error.__traceback__),
            )

    async def _finish_release(self, subscription_id: int, socket: Any) -> None:
        """Complete a release the cleanup deadline cut short, on the same socket.

        A reconnect drops the subscription with the old socket and restarts
        message ids, so on a new socket the id could name an unrelated one.
        """
        if self.websocket is not socket:
            return
        await self._release_abandoned_subscription(subscription_id)

    async def unsubscribe_command(
        self,
        subscription_id: int,
        *,
        unsubscribe_type: str = "unsubscribe_events",
    ) -> None:
        """Tear down a subscription opened via :meth:`subscribe_command`.

        HACS' ``hacs/subscribe`` slots into HA's standard
        ``connection.subscriptions`` map, so ``unsubscribe_events`` cancels
        it the same way it cancels a native ``subscribe_events`` stream
        — ``unsubscribe_type`` is exposed only for the rare case a
        protocol introduces its own teardown command.
        """
        # Always drop the local queue first so any in-flight ``get()``
        # call wakes immediately, even if the HA-side teardown errors.
        self._state.unregister_subscription_queue(subscription_id)

        if not self._state.is_ready:
            logger.debug(
                "unsubscribe_command(%s) skipped: WebSocket not ready",
                subscription_id,
            )
            return
        try:
            await self.send_command(unsubscribe_type, subscription=subscription_id)
        except (OSError, ConnectionClosed, HomeAssistantConnectionError) as e:
            logger.debug(
                "unsubscribe_command(%s): transport lost during cleanup: %s",
                subscription_id,
                e,
            )
        except HomeAssistantCommandError as e:
            logger.warning(
                "unsubscribe_command(%s) rejected by HA: %s",
                subscription_id,
                e,
            )

    def add_event_handler(
        self,
        event_type: str,
        handler: Callable[[dict[str, Any]], Awaitable[None]],
    ) -> None:
        """Add event handler for specific event type.

        Args:
            event_type: Event type to handle (e.g., 'state_changed')
            handler: Async function to handle events
        """
        self._state.add_event_handler(event_type, handler)

    def remove_event_handler(
        self,
        event_type: str,
        handler: Callable[[dict[str, Any]], Awaitable[None]],
    ) -> None:
        """Remove event handler."""
        self._state.remove_event_handler(event_type, handler)

    async def get_states(self) -> dict[str, Any]:
        """Get all entity states via WebSocket."""
        return await self.send_command("get_states")

    async def get_config(self) -> dict[str, Any]:
        """Get Home Assistant configuration via WebSocket."""
        return await self.send_command("get_config")

    async def call_service(
        self,
        domain: str,
        service: str,
        service_data: dict[str, Any] | None = None,
        target: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Call Home Assistant service via WebSocket.

        Args:
            domain: Service domain (e.g., 'light')
            service: Service name (e.g., 'turn_on')
            service_data: Service parameters
            target: Service target (entity_id, area_id, etc.)

        Returns:
            Service call response
        """
        kwargs: dict[str, Any] = {"domain": domain, "service": service}

        if service_data:
            kwargs["service_data"] = service_data
        if target:
            kwargs["target"] = target

        return await self.send_command("call_service", **kwargs)

    async def ping(self) -> bool:
        """Ping Home Assistant to check connection health.

        Returns:
            True if ping successful
        """
        try:
            response = await self.send_command("ping")
            return response.get("type") == "pong"
        except Exception:  # noqa: BLE001
            return False

    @property
    def is_connected(self) -> bool:
        """Check if WebSocket is connected and authenticated."""
        return self._state.is_ready

    @property
    def last_connect_error(self) -> str | None:
        """Reason the most recent ``connect()`` attempt failed, or ``None``.

        Captured from the underlying exception (e.g. an auth timeout, a
        handshake HTTP/TLS error, or "Did not receive auth_required") so
        callers can surface *why* the connection failed instead of an
        opaque "Failed to connect to Home Assistant WebSocket".
        """
        return self._last_connect_error

    @property
    def last_connect_exception(self) -> Exception | None:
        """The exception the most recent ``connect()`` attempt failed with.

        Lets the connection manager preserve the failure class — an
        ``HomeAssistantAuthError`` re-raises as an auth error rather than
        being collapsed into ``HomeAssistantConnectionError``.
        """
        return self._last_connect_exception


MAX_POOL_SIZE = 50


def _log_stale_disconnect(future: "concurrent.futures.Future[None]") -> None:
    """Report how a disconnect scheduled on a stale event loop ended.

    Nothing awaits that future, so without this the outcome would be invisible
    at every log level: a ``concurrent.futures.Future`` never warns about an
    exception no one retrieved.
    """
    if future.cancelled():
        logger.debug("Stale WebSocket disconnect was cancelled with its loop")
        return
    error = future.exception()
    if error is not None:
        logger.debug("Stale WebSocket disconnect failed: %s", error)


class WebSocketManager:
    """Singleton manager for Home Assistant WebSocket connections.

    Maintains a pool of WebSocket connections keyed by (url, token) so that
    multiple OAuth users can have concurrent connections without interfering
    with each other.  The pool is bounded to ``MAX_POOL_SIZE`` entries; when
    this limit is exceeded the least-recently-used connection is evicted.
    """

    _instance = None
    _clients: dict[str, HomeAssistantWebSocketClient]
    _last_used: dict[str, float]
    _current_loop: asyncio.AbstractEventLoop | None = None
    _lock: asyncio.Lock | None = None
    _lock_loop: asyncio.AbstractEventLoop | None = None
    _client_factory: Callable[..., HomeAssistantWebSocketClient] | None = None

    def __new__(cls) -> "WebSocketManager":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._clients = {}
            cls._instance._last_used = {}
            cls._instance._lock = None
            cls._instance._lock_loop = None
            cls._instance._client_factory = HomeAssistantWebSocketClient
        return cls._instance

    def configure(
        self,
        *,
        client_factory: Callable[..., HomeAssistantWebSocketClient] | None = None,
    ) -> None:
        """Configure the manager with injectable dependencies."""
        if client_factory is not None:
            self._client_factory = client_factory

    def _ensure_lock(self) -> None:
        """Ensure lock is created in the current event loop."""
        try:
            current_loop = asyncio.get_running_loop()
        except RuntimeError:
            current_loop = None

        if (
            self._lock is not None
            and self._lock_loop is not None
            and self._lock_loop != current_loop
        ):
            logger.debug("Event loop changed, resetting WebSocketManager lock")
            self._lock = None

        if self._lock is None:
            self._lock = asyncio.Lock()
            self._lock_loop = current_loop
            logger.debug("Created new WebSocketManager lock for current event loop")

    @staticmethod
    def _client_key(url: str, token: str) -> str:
        """Create a cache key from credentials."""
        return hashlib.sha256(f"{url.rstrip('/')}:{token}".encode()).hexdigest()

    def _pool_key(
        self, url: str | None, token: str | None, verify_ssl: bool | None
    ) -> tuple[str, str, str]:
        """The credentials a caller connects with, and their pool key."""
        if url and token:
            ws_url, ws_token = url, token
        else:
            settings = get_global_settings()
            ws_url = settings.homeassistant_url
            ws_token = settings.homeassistant_token
        # Key on the EFFECTIVE verification mode: a caller passing the
        # resolved settings default (send_websocket_message) must share
        # the pooled connection with callers that omit the argument
        # (listener, HACS, installer) — only a genuine override such as
        # verify_ssl=False gets its own isolated connection.
        key = (
            f"{self._client_key(ws_url, ws_token)}"
            f"|verify_ssl={self._effective_verify_ssl(verify_ssl)}"
        )
        return ws_url, ws_token, key

    def pooled_client(
        self,
        url: str | None = None,
        token: str | None = None,
        verify_ssl: bool | None = None,
    ) -> HomeAssistantWebSocketClient | None:
        """The pool's client for these credentials, without connecting.

        It may be disconnected: ``get_client`` replaces such a client only on
        its next call. None when the pool holds none for them.
        """
        return self._clients.get(self._pool_key(url, token, verify_ssl)[2])

    @staticmethod
    def _effective_verify_ssl(verify_ssl: bool | None) -> bool:
        """Resolve the effective TLS-verification mode for the pool key."""
        if verify_ssl is not None:
            return verify_ssl
        try:
            return bool(get_global_settings().verify_ssl)
        except Exception as e:  # noqa: BLE001
            # Mirror HomeAssistantWebSocketClient.__init__: a bad env var
            # elsewhere should not crash pooling or silently flip TLS off.
            logger.warning(
                "Could not load settings while resolving the pool verify_ssl "
                "key (%s); falling back to verify_ssl=True.",
                e,
            )
            return True

    @staticmethod
    def _release_stale_clients(
        clients: list[HomeAssistantWebSocketClient],
        loop: asyncio.AbstractEventLoop | None,
    ) -> None:
        """Best-effort cleanup of clients orphaned by an event-loop change.

        Never awaits: the connections belong to ``loop``, and awaiting them
        from the loop that replaced it is exactly the cross-loop failure this
        avoids. Each disconnect is scheduled on the owning loop and
        deliberately not waited for. A merely stopped loop is scheduled too:
        it still owns live transports and still accepts callbacks, so the
        disconnect runs once that loop is resumed, and otherwise stays an
        unrun callback like any other the abandoned loop still holds. Only a
        closed or unknown loop has nothing left to schedule on; its
        connection is abandoned and the socket closes when the orphaned
        transport is garbage-collected (with a ``ResourceWarning``), because
        closing a loop does not close the transports it carried. Either way
        the caller has already detached the pool, so a failure here cannot
        make it stale again.
        """
        if not clients:
            return
        if loop is None or loop.is_closed():
            logger.debug(
                "Abandoning %d stale WebSocket client(s): the owning event "
                "loop is gone",
                len(clients),
            )
            return
        for client in clients:
            coro = client.disconnect()
            try:
                future = asyncio.run_coroutine_threadsafe(coro, loop)
            except RuntimeError:
                # The loop closed between the check above and now. Closing the
                # coroutine keeps it from surfacing as "never awaited". The
                # narrower window stays open by construction: a loop that
                # accepts the callback and then stops before draining it never
                # runs the coroutine at all, and ``run_coroutine_threadsafe``
                # needs the coroutine object up front, so there is nothing left
                # to reclaim from this side.
                coro.close()
                logger.debug(
                    "Could not schedule disconnect of a stale WebSocket client",
                    exc_info=True,
                )
                continue
            future.add_done_callback(_log_stale_disconnect)

    async def get_client(
        self,
        url: str | None = None,
        token: str | None = None,
        verify_ssl: bool | None = None,
    ) -> HomeAssistantWebSocketClient:
        """Get WebSocket client, creating connection if needed.

        Maintains a pool of connections keyed by credentials. In OAuth mode,
        each user gets their own connection. In non-OAuth mode, the global
        settings are used as the key.

        Args:
            url: Optional HA URL. If provided with token, uses these
                 credentials instead of global settings. This is required
                 for OAuth mode where each request has its own credentials.
            token: Optional HA token. Must be provided with url.
            verify_ssl: TLS verification override, keyed into the pool so a
                 ``HomeAssistantClient(verify_ssl=False)`` caller never shares
                 a connection built with default verification. ``None`` keeps
                 the client's own settings-based default.
        """
        current_loop = asyncio.get_event_loop()

        self._ensure_lock()

        if not self._lock:
            raise Exception("Lock not initialized")
        async with self._lock:
            previous_loop = self._current_loop
            stale_clients: list[HomeAssistantWebSocketClient] = []
            if previous_loop is not None and previous_loop is not current_loop:
                # Event loop changed: detach the pool BEFORE cleaning it up.
                # The pooled clients' futures belong to ``previous_loop``, so
                # awaiting their ``disconnect()`` here raises ``RuntimeError:
                # ... attached to a different loop``, which used to escape the
                # best-effort catch and leave both the pool and the loop
                # reference stale for every later call (issue #1994).
                stale_clients = list(self._clients.values())
                self._clients.clear()
                self._last_used.clear()

            self._current_loop = current_loop
            self._release_stale_clients(stale_clients, previous_loop)

            ws_url, ws_token, key = self._pool_key(url, token, verify_ssl)

            # Return existing connected client for these credentials
            existing = self._clients.get(key)
            if existing and existing.is_connected:
                self._last_used[key] = time.monotonic()
                return existing

            # Remove stale client if present. Disconnect it too: a client
            # whose connection dropped can still own a parked reader task and
            # a half-open socket, and simply dropping the reference abandons
            # both to garbage collection — the GC's asyncgen finalizer then
            # acloses the reader's ``Connection.__aiter__`` mid-``__anext__``
            # and logs ``aclose(): asynchronous generator is already
            # running`` (issue #2127). Same-loop by construction: a loop
            # change already detached the pool above, so ``existing`` was
            # built on ``current_loop`` and can be awaited here.
            if existing:
                self._clients.pop(key, None)
                self._last_used.pop(key, None)
                try:
                    await existing.disconnect()
                except asyncio.CancelledError:
                    # The caller itself was cancelled mid-cleanup: propagate.
                    # Swallowing here would let a cancelled operation keep
                    # doing network I/O and leave a fresh connection retained
                    # in the pool.
                    raise
                except (OSError, RuntimeError):
                    logger.warning(
                        "Error disconnecting stale WebSocket client",
                        exc_info=True,
                    )

            factory = self._client_factory or HomeAssistantWebSocketClient
            client = (
                factory(ws_url, ws_token)
                if verify_ssl is None
                else factory(ws_url, ws_token, verify_ssl=verify_ssl)
            )

            connected = await client.connect()
            if not connected:
                reason = client.last_connect_error
                # Append only an actual string reason; the isinstance guard
                # keeps a non-str (e.g. a MagicMock in tests) from polluting
                # the message with a repr.
                detail = f": {reason}" if isinstance(reason, str) else ""
                # An auth failure must classify as an auth failure — the
                # collapsed connection error buries the cause in the message
                # string and callers misreport it as connection guidance.
                if isinstance(client.last_connect_exception, HomeAssistantAuthError):
                    raise HomeAssistantAuthError(
                        "WebSocket authentication failed" + detail
                    )
                raise HomeAssistantConnectionError(
                    "Failed to connect to Home Assistant WebSocket" + detail
                )

            self._clients[key] = client
            self._last_used[key] = time.monotonic()

            await self._evict_lru_if_needed()

            return client

    async def _evict_lru_if_needed(self) -> None:
        """Evict the least-recently-used connection if pool exceeds limit."""
        if len(self._clients) <= MAX_POOL_SIZE:
            return
        oldest_key = min(self._last_used, key=lambda k: self._last_used[k])
        stale = self._clients.pop(oldest_key, None)
        self._last_used.pop(oldest_key, None)
        if stale:
            try:
                await stale.disconnect()
            except asyncio.CancelledError:
                # The caller itself was cancelled mid-eviction: propagate.
                # Eviction runs after the fresh client was pooled, so a
                # swallow here would hand a connected client back to a
                # cancelled caller (mirror of the stale-replacement clause
                # in get_client).
                raise
            except (OSError, RuntimeError):
                logger.warning(
                    "Error disconnecting evicted WebSocket client",
                    exc_info=True,
                )

    async def disconnect(self) -> None:
        """Disconnect all WebSocket clients."""
        self._ensure_lock()

        if not self._lock:
            raise Exception("Lock not initialized")
        async with self._lock:
            # Detach the pool before disconnecting so a raising disconnect
            # cannot leave it populated (the bookkeeping half of the
            # loop-change branch in ``get_client``). The only caller,
            # ``__main__``'s shutdown, runs on the pool's own loop, so each
            # ``disconnect()`` is awaited to completion here. ``RuntimeError``
            # is caught purely defensively: were this ever driven from a
            # different loop, the cross-loop future would raise instead of
            # hanging the shutdown. Unlike ``get_client`` it does not
            # reschedule onto the owning loop, because the process is going
            # away and there is nothing left to resume it.
            clients = list(self._clients.values())
            self._clients.clear()
            self._last_used.clear()
            self._current_loop = None
            for client in clients:
                try:
                    await client.disconnect()
                except (OSError, RuntimeError, asyncio.CancelledError):
                    logger.warning(
                        "Error disconnecting WebSocket client", exc_info=True
                    )


# Global WebSocket manager instance
websocket_manager = WebSocketManager()


async def get_websocket_client(
    url: str | None = None,
    token: str | None = None,
    verify_ssl: bool | None = None,
) -> HomeAssistantWebSocketClient:
    """Get the global WebSocket client instance.

    Args:
        url: Optional HA URL for per-client credentials (OAuth mode).
        token: Optional HA token for per-client credentials (OAuth mode).
        verify_ssl: Optional TLS-verification override propagated into the
            pool key and client construction (None = settings default).
    """
    return await websocket_manager.get_client(
        url=url, token=token, verify_ssl=verify_ssl
    )
